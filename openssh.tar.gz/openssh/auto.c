#include <stdio.h>
#include <stdlib.h>
int main()
{
	
	system("mkdir /usr/local/ -p");
	system("mkdir /var/run/  -p");
	system("mkdir /var/empty/ -p");
	
	system("cp ./bin /usr/local/  -R");
	system("cp ./etc /usr/local/  -R");
	system("cp ./libexec /usr/local/  -R");
	system("cp ./sbin /usr/local/  -R");
	
	system("echo sshd:x:74:74:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin >> /etc/passwd");
	
	system("chmod 600 /usr/local/etc/ssh_host_dsa_key");
	system("chmod 600 /usr/local/etc/ssh_host_ecdsa_key");
	system("chmod 600 /usr/local/etc/ssh_host_ed25519_key");
	system("chmod 600 /usr/local/etc/ssh_host_rsa_key");
	
	
	system("echo /usr/local/sbin/sshd >> /etc/init.d/rcS");
	
	system("cp libcrypto.so.1.0.0   /lib");
	system("cp libz.so.1    /lib");
	
	system("echo export PATH=/usr/local/bin:$PATH >> /etc/profile");
	
	
}
